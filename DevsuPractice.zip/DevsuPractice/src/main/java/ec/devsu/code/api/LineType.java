package ec.devsu.code.api;

/**
 * LineType
 */
public enum LineType {
    Horizontal, Vertical, Diagonal;

}