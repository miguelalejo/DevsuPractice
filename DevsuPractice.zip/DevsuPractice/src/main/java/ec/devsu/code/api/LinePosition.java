package ec.devsu.code.api;

/**
 * LinePosition
 */
public enum LinePosition {
    Up, Down, Leff, Right, UpLeft, UpRight, DownLeft, DownRight;

}